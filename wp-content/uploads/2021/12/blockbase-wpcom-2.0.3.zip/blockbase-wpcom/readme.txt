=== Blockbase ===
Contributors: Automattic
Requires at least: 5.7
Tested up to: 5.7.2
Requires PHP: 5.6.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A starting point for building your block-based site.

== Description ==

Blockbase is a simple theme that supports full-site editing. It comes with a set of minimal templates and design settings that can be manipulated through Global Styles. Use it to build something beautiful.

== About Blockbase ==

For more information see our README.md file.
Read the release notes at https://blockbasetheme.com/category/release-notes/

== Changelog ==

= 7 December 2021 =
* D71158

= 6 December 2021 =
* D71075

= 2 December 2021 =
* D70934

= 29 November 2021 =
* D70754

= 26 November 2021 =
* Deploy Themes 1.0.41 to wpcom

= 24 November 2021 =
* D70574

= 21 November 2021 =
* D70421

= 19 November 2021 =
* D70358

= 18 November 2021 =
* D70301
* Deploy Themes 1.0.39 to wpcom

= 17 November 2021 =
* D70241
* D70215

= 12 November 2021 =
* D70038

= 10 November 2021 =
* D69883

= 4 November 2021 =
* D69650

= 3 November 2021 =
* Deploy Themes 1.0.35 to wpcom

= 29 October 2021 =
* D69262

= 28 October 2021 =
* D69179

= 27 October 2021 =
* D69089

= 26 October 2021 =
* D69041
* D69026

= 25 October 2021 =
* D68946

= 21 October 2021 =
* D68851

= 20 October 2021 =
* D68775

= 19 October 2021 =
* D68672
* D68631
* D68612

= 15 October 2021 =
* Deploy Themes 1.0.15 to wpcom

= 14 October 2021 =
* Deploy Themes 1.0.13 to wpcom

= 12 October 2021 =
* D68283

= 11 October 2021 =
* D68239

= 7 October 2021 =
* Syncs the latest changes from GitHub

= 6 October 2021 =
* Deploy Themes 1.0.7 to wpcom

= 5 October 2021 =
* D67904

= 4 October 2021 =
* Deploy Themes 1.0.6 to wpcom

= 1 October 2021 =
* D67733

= 30 September 2021 =
* D67667

= 29 September 2021 =
* Sync GitHub to SVN
* bug

= 28 September 2021 =
* Add Headstart annotations
* Add .pot file
* Syncing GitHub to SVN
* Deploy Themes 1.0.3 to wpcom

= 24 September 2021 =
* Sync GitHub to SVN

= 23 September 2021 =
* Sync GitHub to SVN

= 22 September 2021 =
* Sync GitHub to SVN

= 20 September 2021 =
* Sync GitHub and SVN

= 13 September 2021 =
* Deploy Themes 1.0.1 to wpcom

= 10 September 2021 =
* Sync themes from GitHub to SVN

= 9 September 2021 =
* Update from GitHub

= 8 September 2021 =
* SVN - Git sync of latest block themes changes

= 2 September 2021 =
* Bringing SVN up to date from GitHub

= 24 August 2021 =
* Brings the latest Blockbase and Family changes from GIT to SVN

= 23 August 2021 =
* Blockbase + Children sync

= 18 August 2021 =
* Sync Blockbase and children from GH repo

= 5 August 2021 =
* Update SVN from GitHub

= 3 August 2021 =
* remove site editor toggle (part 2)
* remove site editor toggle

= 21 July 2021 =
* Sync changes from GIT>SVN

= 20 July 2021 =
* Syncing GitHub with SVN.

= 16 July 2021 =
* Update from GitHub

= 15 July 2021 =
* Updating SVN from GitHub

= 9 July 2021 =
* Syncing Blockbase and children from GitHub

= 1 July 2021 =
* Remove files whose name was changed.
* Syncing changes from GitHub to SVN

= 28 June 2021 =
* Sync GitHub to SVN

= 25 June 2021 =
* Try/quadrat semantic color customizations

= 24 June 2021 =
* Add a link to WordPress.com to the blockbase theme footer credits
* Add a link to WordPress.com to the blockbase theme footer credits

= 23 June 2021 =
* Add template with just a header and footer

= 11 June 2021 =
* Sync changes from GitHub

= 10 June 2021 =
* Update themes from GitHub
* Remove files that were removed in GitHub

= 8 June 2021 =
* Sync changes from GitHub

= 27 May 2021 =
* Blockbase + child themes update

= 25 May 2021 =
* Add a new themes "blockbase" as a parent block theme

== Copyright ==

Blockbase WordPress Theme, (C) 2021 Automattic, Inc.
Blockbase is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

Blockbase uses the following third-party resources:

The Water Fan, by Winslow Homer
License: CC0
Source: https://www.artic.edu/artworks/38666/the-water-fan
Included in theme screenshot.

Colord library
License: MIT
Source: https://github.com/omgovich/colord
